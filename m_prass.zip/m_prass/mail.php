<?php
$to = 'markhanprasetiyo@gmail.com';
$firstname = $_POST["name"];
$email = $_POST["email"];
$text = $_POST["message"];
$subject = $_POST['subject'];
// $phone= $_POST["phone"];


$message = '<table style="width:100%">
        <tr>
            <td>' . $firstname . '</td>
        </tr>
        <tr><td>Email: ' . $email . '</td></tr>
        <tr><td>Text: ' . $text . '</td></tr>
        
    </table>';
ini_set('display_errors', 1);
error_reporting(E_ALL);
// $from = "test@hostinger-tutorials.com";
// $to = "test@hostinger.com";
// $subject = "Checking PHP mail";
// $message = "PHP mail works just fine";
$headers = "From:" . $email;
mail($to, $subject, $message, $headers);
echo "The email message was sent.";
